:- object(lock_fixture_registry,
	implements(registry_protocol)).

	name(lock_fixture).
	description('Lock regression registry').
	home('file://test_files/logtalk_packs/lock_fixture').
	clone('file://test_files/logtalk_packs/lock_fixture').
	archive('file://test_files/logtalk_packs/lock_fixture.zip').

:- end_object.