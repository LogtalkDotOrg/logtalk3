:- initialization(logtalk_load([
	lock_fixture_registry,
	lock_a_pack,
	lock_b_pack,
	lock_c_pack,
	lock_d_pack,
	lock_cycle_a_pack,
	lock_cycle_b_pack,
	lock_bad_pack,
	lock_impossible_pack
])).