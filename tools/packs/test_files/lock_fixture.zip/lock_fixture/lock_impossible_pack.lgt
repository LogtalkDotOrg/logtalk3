:- object(lock_impossible_pack,
	implements(pack_protocol)).

	name(lock_impossible).
	description('Lock regression pack').
	license('Apache-2.0').
	home('file://test_files/asc').
	version(
		1:0:0,
		stable,
		'file://test_files/asc/v1.0.0.tar.gz',
		sha256-'27ddfdb1bfd6efd86f4c1627bd7409ff0f9092551193007ca0d576c1f49fa959',
		[lock_fixture::lock_b @>= 2],
		all
	).

:- end_object.