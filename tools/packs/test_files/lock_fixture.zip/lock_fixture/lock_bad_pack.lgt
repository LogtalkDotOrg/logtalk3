:- object(lock_bad_pack,
	implements(pack_protocol)).

	name(lock_bad).
	description('Lock regression pack').
	license('Apache-2.0').
	home('file://test_files/asc').
	version(
		1:0:0,
		stable,
		'file://test_files/asc/v1.0.0.tar.gz',
		sha256-'0000000000000000000000000000000000000000000000000000000000000000',
		[],
		all
	).

:- end_object.