:- object(repo_pack,
	implements(pack_protocol)).

	name(repo).

	description('A pack used to test git registry lockfiles').

	license('Apache-2.0').

	home('file://test_files/foo').

	version(
		2:0:0,
		stable,
		'file://test_files/foo',
		none,
		[logtalk @>= 3:42:0],
		all
	).

:- end_object.
