:- initialization((
	logtalk_load(repo_registry),
	logtalk_load(repo_pack)
)).
