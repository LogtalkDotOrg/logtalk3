:- object(repo_registry,
	implements(registry_protocol)).

	name(repo).

	description('A git repository registry for lockfile testing').

	home('file:///tmp/repo').

	clone('file:///tmp/repo.git').

	archive('file:///tmp/repo.zip').

:- end_object.
